<div class="footer">
    <div class="pull-right hidden-xs">
		<small>Producto desarrollado por <strong><i class="fa fa-coffee" aria-hidden="true"></i> Guayoyo Software, C.A</strong></small>
    </div>
    <div>
		<strong>Copyright</strong> {{ Session::get('company_name') }} &copy; 2017
    </div>
</div>